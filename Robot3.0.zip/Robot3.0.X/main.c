#include "mcc_generated_files/system/system.h"
#include <stdint.h>
#include <stdio.h>

#define LEFT_SENSOR   ADC_CHANNEL_ANC4
#define RIGHT_SENSOR  ADC_CHANNEL_ANB6
#define FRONT_SENSOR  ADC_CHANNEL_ANC5

#define BASE_L 7
#define BASE_R 7

#define FRONT_TRIGGER  350
#define FRONT_CLOSE    400

#define LEFT_FAR    350
#define LEFT_CLOSE  470
#define LEFT_STUCK  650

#define RIGHT_CLOSE 700

#define LEFT_TARGET 500
#define LEFT_MARGIN 70

// NEW: distance to clear the corner before turning left
#define LEFT_CLEAR_FORWARD_TIME 260

void setSpeedLR(uint8_t leftPercent, uint8_t rightPercent)
{
    if(leftPercent > 100) leftPercent = 100;
    if(rightPercent > 100) rightPercent = 100;

    uint16_t leftDuty  = (uint16_t)(((uint32_t)leftPercent  * 4095UL) / 100UL);
    uint16_t rightDuty = (uint16_t)(((uint32_t)rightPercent * 4095UL) / 100UL);

    PWM1_16BIT_SetSlice1Output1DutyCycleRegister(rightDuty);
    PWM1_16BIT_SetSlice1Output2DutyCycleRegister(leftDuty);

    PWM1_16BIT_LoadBufferRegisters();
}

void stopMotors(void)
{
    PWM1_16BIT_SetSlice1Output1DutyCycleRegister(0);
    PWM1_16BIT_SetSlice1Output2DutyCycleRegister(0);
    PWM1_16BIT_LoadBufferRegisters();
}

void driveForward(uint8_t leftSpeed, uint8_t rightSpeed)
{
    DIR_L_SetLow();
    DIR_R_SetLow();
    setSpeedLR(leftSpeed, rightSpeed);
}

void driveBackward(uint8_t leftSpeed, uint8_t rightSpeed)
{
    DIR_L_SetHigh();
    DIR_R_SetHigh();
    setSpeedLR(leftSpeed, rightSpeed);
}

void turnRight(void)
{
    DIR_L_SetLow();
    DIR_R_SetHigh();

    setSpeedLR(10, 10);
    __delay_ms(420);

    stopMotors();
    __delay_ms(40);
}

void turnLeftSoft(void)
{
    DIR_L_SetHigh();
    DIR_R_SetLow();

    setSpeedLR(7, 7);
    __delay_ms(240);

    stopMotors();
    __delay_ms(40);
}

void main(void)
{
    SYSTEM_Initialize();

    PWM1_16BIT_Initialize();
    PWM1_16BIT_Enable();

    stopMotors();
    __delay_ms(500);

    printf("\r\nLEFT WALL FOLLOWER WITH LEFT CLEARANCE\r\n");

    while(1)
    {
        uint16_t left;
        uint16_t right;
        uint16_t front;

        left = (uint16_t)ADC_ChannelSelectAndConvert(LEFT_SENSOR);
        __delay_ms(2);

        right = (uint16_t)ADC_ChannelSelectAndConvert(RIGHT_SENSOR);
        __delay_ms(2);

        front = (uint16_t)ADC_ChannelSelectAndConvert(FRONT_SENSOR);
        __delay_ms(2);

        printf("L:%u F:%u R:%u\r\n", left, front, right);

        if((left < LEFT_FAR) &&
           (right < RIGHT_CLOSE) &&
           (front < FRONT_TRIGGER))
        {
            printf("LEFT OPENING - CLEAR THEN TURN LEFT\r\n");

            // NEW: move forward longer before turning left
            // This lets the robot clear the corner/wall before rotating.
            driveForward(BASE_L, BASE_R);
            __delay_ms(LEFT_CLEAR_FORWARD_TIME);

            stopMotors();
            __delay_ms(30);

            turnLeftSoft();

            driveForward(BASE_L, BASE_R);
            __delay_ms(120);

            continue;
        }

        else if(front > FRONT_CLOSE && left > LEFT_CLOSE)
        {
            printf("DEAD END - TURN RIGHT\r\n");

            stopMotors();
            __delay_ms(50);

            driveBackward(6, 6);
            __delay_ms(120);

            stopMotors();
            __delay_ms(50);

            turnRight();

            continue;
        }

        else if(front > FRONT_TRIGGER)
        {
            printf("FRONT BLOCKED - TURN RIGHT\r\n");

            stopMotors();
            __delay_ms(50);

            driveBackward(5, 5);
            __delay_ms(80);

            stopMotors();
            __delay_ms(50);

            turnRight();

            continue;
        }

        else if(right > RIGHT_CLOSE)
        {
            printf("RIGHT CLOSE - CORRECT LEFT\r\n");

            driveForward(5, 8);
            __delay_ms(40);

            continue;
        }

        else if(left > LEFT_STUCK)
        {
            printf("LEFT STUCK - HARD RIGHT CORRECTION\r\n");

            driveForward(10, 4);
            __delay_ms(70);

            continue;
        }

        else if(left > (LEFT_TARGET + LEFT_MARGIN))
        {
            printf("MAINTAIN DISTANCE - MOVE RIGHT\r\n");

            driveForward(10, 7);
            __delay_ms(45);

            continue;
        }

        else if(left < (LEFT_TARGET - LEFT_MARGIN))
        {
            printf("MAINTAIN DISTANCE - MOVE LEFT\r\n");

            driveForward(7, 10);
            __delay_ms(45);

            continue;
        }

        else
        {
            printf("STRAIGHT - GOOD LEFT DISTANCE\r\n");

            driveForward(BASE_L, BASE_R);
            __delay_ms(60);
        }

        __delay_ms(5);
    }
}