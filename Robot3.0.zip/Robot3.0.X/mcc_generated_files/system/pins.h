/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2026] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA2 aliases
#define DIR_R_TRIS                 TRISAbits.TRISA2
#define DIR_R_LAT                  LATAbits.LATA2
#define DIR_R_PORT                 PORTAbits.RA2
#define DIR_R_WPU                  WPUAbits.WPUA2
#define DIR_R_OD                   ODCONAbits.ODCA2
#define DIR_R_ANS                  ANSELAbits.ANSELA2
#define DIR_R_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define DIR_R_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define DIR_R_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define DIR_R_GetValue()           PORTAbits.RA2
#define DIR_R_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define DIR_R_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define DIR_R_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define DIR_R_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define DIR_R_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define DIR_R_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define DIR_R_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define DIR_R_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RA4 aliases
#define PWM_R_TRIS                 TRISAbits.TRISA4
#define PWM_R_LAT                  LATAbits.LATA4
#define PWM_R_PORT                 PORTAbits.RA4
#define PWM_R_WPU                  WPUAbits.WPUA4
#define PWM_R_OD                   ODCONAbits.ODCA4
#define PWM_R_ANS                  ANSELAbits.ANSELA4
#define PWM_R_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define PWM_R_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define PWM_R_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define PWM_R_GetValue()           PORTAbits.RA4
#define PWM_R_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define PWM_R_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define PWM_R_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define PWM_R_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define PWM_R_SetPushPull()        do { ODCONAbits.ODCA4 = 0; } while(0)
#define PWM_R_SetOpenDrain()       do { ODCONAbits.ODCA4 = 1; } while(0)
#define PWM_R_SetAnalogMode()      do { ANSELAbits.ANSELA4 = 1; } while(0)
#define PWM_R_SetDigitalMode()     do { ANSELAbits.ANSELA4 = 0; } while(0)

// get/set RA5 aliases
#define ALARM_LED_TRIS                 TRISAbits.TRISA5
#define ALARM_LED_LAT                  LATAbits.LATA5
#define ALARM_LED_PORT                 PORTAbits.RA5
#define ALARM_LED_WPU                  WPUAbits.WPUA5
#define ALARM_LED_OD                   ODCONAbits.ODCA5
#define ALARM_LED_ANS                  ANSELAbits.ANSELA5
#define ALARM_LED_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define ALARM_LED_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define ALARM_LED_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define ALARM_LED_GetValue()           PORTAbits.RA5
#define ALARM_LED_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define ALARM_LED_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define ALARM_LED_SetPullup()          do { WPUAbits.WPUA5 = 1; } while(0)
#define ALARM_LED_ResetPullup()        do { WPUAbits.WPUA5 = 0; } while(0)
#define ALARM_LED_SetPushPull()        do { ODCONAbits.ODCA5 = 0; } while(0)
#define ALARM_LED_SetOpenDrain()       do { ODCONAbits.ODCA5 = 1; } while(0)
#define ALARM_LED_SetAnalogMode()      do { ANSELAbits.ANSELA5 = 1; } while(0)
#define ALARM_LED_SetDigitalMode()     do { ANSELAbits.ANSELA5 = 0; } while(0)

// get/set RB5 aliases
#define IO_RB5_TRIS                 TRISBbits.TRISB5
#define IO_RB5_LAT                  LATBbits.LATB5
#define IO_RB5_PORT                 PORTBbits.RB5
#define IO_RB5_WPU                  WPUBbits.WPUB5
#define IO_RB5_OD                   ODCONBbits.ODCB5
#define IO_RB5_ANS                  ANSELBbits.ANSELB5
#define IO_RB5_SetHigh()            do { LATBbits.LATB5 = 1; } while(0)
#define IO_RB5_SetLow()             do { LATBbits.LATB5 = 0; } while(0)
#define IO_RB5_Toggle()             do { LATBbits.LATB5 = ~LATBbits.LATB5; } while(0)
#define IO_RB5_GetValue()           PORTBbits.RB5
#define IO_RB5_SetDigitalInput()    do { TRISBbits.TRISB5 = 1; } while(0)
#define IO_RB5_SetDigitalOutput()   do { TRISBbits.TRISB5 = 0; } while(0)
#define IO_RB5_SetPullup()          do { WPUBbits.WPUB5 = 1; } while(0)
#define IO_RB5_ResetPullup()        do { WPUBbits.WPUB5 = 0; } while(0)
#define IO_RB5_SetPushPull()        do { ODCONBbits.ODCB5 = 0; } while(0)
#define IO_RB5_SetOpenDrain()       do { ODCONBbits.ODCB5 = 1; } while(0)
#define IO_RB5_SetAnalogMode()      do { ANSELBbits.ANSELB5 = 1; } while(0)
#define IO_RB5_SetDigitalMode()     do { ANSELBbits.ANSELB5 = 0; } while(0)

// get/set RB6 aliases
#define RightSensor_TRIS                 TRISBbits.TRISB6
#define RightSensor_LAT                  LATBbits.LATB6
#define RightSensor_PORT                 PORTBbits.RB6
#define RightSensor_WPU                  WPUBbits.WPUB6
#define RightSensor_OD                   ODCONBbits.ODCB6
#define RightSensor_ANS                  ANSELBbits.ANSELB6
#define RightSensor_SetHigh()            do { LATBbits.LATB6 = 1; } while(0)
#define RightSensor_SetLow()             do { LATBbits.LATB6 = 0; } while(0)
#define RightSensor_Toggle()             do { LATBbits.LATB6 = ~LATBbits.LATB6; } while(0)
#define RightSensor_GetValue()           PORTBbits.RB6
#define RightSensor_SetDigitalInput()    do { TRISBbits.TRISB6 = 1; } while(0)
#define RightSensor_SetDigitalOutput()   do { TRISBbits.TRISB6 = 0; } while(0)
#define RightSensor_SetPullup()          do { WPUBbits.WPUB6 = 1; } while(0)
#define RightSensor_ResetPullup()        do { WPUBbits.WPUB6 = 0; } while(0)
#define RightSensor_SetPushPull()        do { ODCONBbits.ODCB6 = 0; } while(0)
#define RightSensor_SetOpenDrain()       do { ODCONBbits.ODCB6 = 1; } while(0)
#define RightSensor_SetAnalogMode()      do { ANSELBbits.ANSELB6 = 1; } while(0)
#define RightSensor_SetDigitalMode()     do { ANSELBbits.ANSELB6 = 0; } while(0)

// get/set RB7 aliases
#define IO_RB7_TRIS                 TRISBbits.TRISB7
#define IO_RB7_LAT                  LATBbits.LATB7
#define IO_RB7_PORT                 PORTBbits.RB7
#define IO_RB7_WPU                  WPUBbits.WPUB7
#define IO_RB7_OD                   ODCONBbits.ODCB7
#define IO_RB7_ANS                  ANSELBbits.ANSELB7
#define IO_RB7_SetHigh()            do { LATBbits.LATB7 = 1; } while(0)
#define IO_RB7_SetLow()             do { LATBbits.LATB7 = 0; } while(0)
#define IO_RB7_Toggle()             do { LATBbits.LATB7 = ~LATBbits.LATB7; } while(0)
#define IO_RB7_GetValue()           PORTBbits.RB7
#define IO_RB7_SetDigitalInput()    do { TRISBbits.TRISB7 = 1; } while(0)
#define IO_RB7_SetDigitalOutput()   do { TRISBbits.TRISB7 = 0; } while(0)
#define IO_RB7_SetPullup()          do { WPUBbits.WPUB7 = 1; } while(0)
#define IO_RB7_ResetPullup()        do { WPUBbits.WPUB7 = 0; } while(0)
#define IO_RB7_SetPushPull()        do { ODCONBbits.ODCB7 = 0; } while(0)
#define IO_RB7_SetOpenDrain()       do { ODCONBbits.ODCB7 = 1; } while(0)
#define IO_RB7_SetAnalogMode()      do { ANSELBbits.ANSELB7 = 1; } while(0)
#define IO_RB7_SetDigitalMode()     do { ANSELBbits.ANSELB7 = 0; } while(0)

// get/set RC4 aliases
#define LeftSensor_TRIS                 TRISCbits.TRISC4
#define LeftSensor_LAT                  LATCbits.LATC4
#define LeftSensor_PORT                 PORTCbits.RC4
#define LeftSensor_WPU                  WPUCbits.WPUC4
#define LeftSensor_OD                   ODCONCbits.ODCC4
#define LeftSensor_ANS                  ANSELCbits.ANSELC4
#define LeftSensor_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define LeftSensor_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define LeftSensor_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define LeftSensor_GetValue()           PORTCbits.RC4
#define LeftSensor_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define LeftSensor_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define LeftSensor_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define LeftSensor_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define LeftSensor_SetPushPull()        do { ODCONCbits.ODCC4 = 0; } while(0)
#define LeftSensor_SetOpenDrain()       do { ODCONCbits.ODCC4 = 1; } while(0)
#define LeftSensor_SetAnalogMode()      do { ANSELCbits.ANSELC4 = 1; } while(0)
#define LeftSensor_SetDigitalMode()     do { ANSELCbits.ANSELC4 = 0; } while(0)

// get/set RC5 aliases
#define FrontSensor_TRIS                 TRISCbits.TRISC5
#define FrontSensor_LAT                  LATCbits.LATC5
#define FrontSensor_PORT                 PORTCbits.RC5
#define FrontSensor_WPU                  WPUCbits.WPUC5
#define FrontSensor_OD                   ODCONCbits.ODCC5
#define FrontSensor_ANS                  ANSELCbits.ANSELC5
#define FrontSensor_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define FrontSensor_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define FrontSensor_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define FrontSensor_GetValue()           PORTCbits.RC5
#define FrontSensor_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define FrontSensor_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define FrontSensor_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define FrontSensor_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define FrontSensor_SetPushPull()        do { ODCONCbits.ODCC5 = 0; } while(0)
#define FrontSensor_SetOpenDrain()       do { ODCONCbits.ODCC5 = 1; } while(0)
#define FrontSensor_SetAnalogMode()      do { ANSELCbits.ANSELC5 = 1; } while(0)
#define FrontSensor_SetDigitalMode()     do { ANSELCbits.ANSELC5 = 0; } while(0)

// get/set RC6 aliases
#define PWM_L_TRIS                 TRISCbits.TRISC6
#define PWM_L_LAT                  LATCbits.LATC6
#define PWM_L_PORT                 PORTCbits.RC6
#define PWM_L_WPU                  WPUCbits.WPUC6
#define PWM_L_OD                   ODCONCbits.ODCC6
#define PWM_L_ANS                  ANSELCbits.ANSELC6
#define PWM_L_SetHigh()            do { LATCbits.LATC6 = 1; } while(0)
#define PWM_L_SetLow()             do { LATCbits.LATC6 = 0; } while(0)
#define PWM_L_Toggle()             do { LATCbits.LATC6 = ~LATCbits.LATC6; } while(0)
#define PWM_L_GetValue()           PORTCbits.RC6
#define PWM_L_SetDigitalInput()    do { TRISCbits.TRISC6 = 1; } while(0)
#define PWM_L_SetDigitalOutput()   do { TRISCbits.TRISC6 = 0; } while(0)
#define PWM_L_SetPullup()          do { WPUCbits.WPUC6 = 1; } while(0)
#define PWM_L_ResetPullup()        do { WPUCbits.WPUC6 = 0; } while(0)
#define PWM_L_SetPushPull()        do { ODCONCbits.ODCC6 = 0; } while(0)
#define PWM_L_SetOpenDrain()       do { ODCONCbits.ODCC6 = 1; } while(0)
#define PWM_L_SetAnalogMode()      do { ANSELCbits.ANSELC6 = 1; } while(0)
#define PWM_L_SetDigitalMode()     do { ANSELCbits.ANSELC6 = 0; } while(0)

// get/set RC7 aliases
#define DIR_L_TRIS                 TRISCbits.TRISC7
#define DIR_L_LAT                  LATCbits.LATC7
#define DIR_L_PORT                 PORTCbits.RC7
#define DIR_L_WPU                  WPUCbits.WPUC7
#define DIR_L_OD                   ODCONCbits.ODCC7
#define DIR_L_ANS                  ANSELCbits.ANSELC7
#define DIR_L_SetHigh()            do { LATCbits.LATC7 = 1; } while(0)
#define DIR_L_SetLow()             do { LATCbits.LATC7 = 0; } while(0)
#define DIR_L_Toggle()             do { LATCbits.LATC7 = ~LATCbits.LATC7; } while(0)
#define DIR_L_GetValue()           PORTCbits.RC7
#define DIR_L_SetDigitalInput()    do { TRISCbits.TRISC7 = 1; } while(0)
#define DIR_L_SetDigitalOutput()   do { TRISCbits.TRISC7 = 0; } while(0)
#define DIR_L_SetPullup()          do { WPUCbits.WPUC7 = 1; } while(0)
#define DIR_L_ResetPullup()        do { WPUCbits.WPUC7 = 0; } while(0)
#define DIR_L_SetPushPull()        do { ODCONCbits.ODCC7 = 0; } while(0)
#define DIR_L_SetOpenDrain()       do { ODCONCbits.ODCC7 = 1; } while(0)
#define DIR_L_SetAnalogMode()      do { ANSELCbits.ANSELC7 = 1; } while(0)
#define DIR_L_SetDigitalMode()     do { ANSELCbits.ANSELC7 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/